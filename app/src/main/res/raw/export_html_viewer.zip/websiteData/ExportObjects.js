class User {
    /** @type {String} */ _userId;
    /** @type {String} */ _name;
    /** @type {Number} */ _accent_color;
    /** @type {Boolean} */ _isSelf;
    /** @type {String} */ _username;
    /** @type {String} */ _teamId;
    /** @type {String} */ _email;
    /** @type {String} */ _phone;
    /** @type {String} */ _trackingId;
    /** @type {ProfilePicture} */ _picture;
    /** @type {String} */ _userFields;
    /** @type {String} */ _permission;
    /**
     * @param {String} userId
     * @param {String} name
     * @param {Number} accent_color
     */
    constructor(userId, name, accent_color) {
        this._userId = userId;
        this._name = name;
        this._accent_color = accent_color;
        this._isSelf=false;
        this._username=null;
        this._teamId=null;
        this._email=null;
        this._phone=null;
        this._trackingId=null;
        this._picture=null;
        this._userFields=null;
        this._permission=null;
    }
    /** @param {String} value */ set username(value) { this._username = "@"+value; }
    /** @param {String} value */ set teamId(value) { this._teamId = value; }
    /** @param {String} value */ set email(value) { this._email = value; }
    /** @param {String} value */ set phone(value) { this._phone = value; }
    /** @param {String} value */ set trackingId(value) { this._trackingId = value; }
    /** @param {ProfilePicture} value */ set picture(value) { this._picture = value; }
    /** @param {String} value */ set userFields(value) { this._userFields = value; }
    /** @param {String} value */ set permission(value) { this._permission = value; }
    /** @param {Boolean} value */ set isSelf(value) { this._isSelf = value; }
    /** @returns {Boolean} */ get isSelf() { return this._isSelf;}
    /** @returns {String} */ get userId() { return this._userId; }
    /** @returns {String} */ get name() { return this._name; }
    /** @returns {Number} */ get accent_color() { return this._accent_color; }
    /** @returns {String} */ get username() { return this._username; }
    /** @returns {String} */ get teamId() { return this._teamId; }
    /** @returns {String} */ get email() { return this._email; }
    /** @returns {String} */ get phone() { return this._phone; }
    /** @returns {String} */ get trackingId() { return this._trackingId; }
    /** @returns {ProfilePicture} */ get picture() { return this._picture; }
    /** @returns {String} */ get userFields() { return this._userFields; }
    /** @returns {String} */ get permission() { return this._permission; }
    /** @returns {String} */
    getShort(){
        if(this.name.length>1)
            return this.name.substr(0,2).toUpperCase();
        else
            return this.name.toUpperCase();
    }
    /** @returns {String} */
    getSalutation(){
        return this.isSelf?"You":this.name;
    }
}

class ProfilePicture {
    /** @type {String} */ _filename;
    /** @type {Boolean} */ _uploaded;
    /**
     * @param {String} filename
     */
    constructor(filename){
        this._filename = filename;
        this._uploaded = false;
    }
    /** @param {Boolean} value */ set uploaded(value) { this._uploaded = value; }
    /** @returns {String} */ get filename() { return this._filename; }
    /** @returns {Boolean} */ get uploaded() { return this._uploaded; }
}

class Conversation{
    /** @type {String} */ _id;
    /** @type {String} */ _remoteId;
    /** @type {String} */ _creator;
    /** @type {String} */ _type;
    /** @type {String} */ _verified;
    /** @type {Map<String,String>} */ _userRoles;
    /** @type {Map<String,Message>} */ _messages;
    /** @type {String} */ _name;
    /** @type {String} */ _teamId;
    /** @type {String[]} */ _access;
    /** @type {String} */ _accessRole;
    /** @type {String} */ _link;

    /**
     * @param {String} id
     * @param {String} remoteId
     * @param {String} creator
     * @param {String} type
     * @param {String} verified
     */
    constructor(id, remoteId, creator, type, verified){
        this._id = id;
        this._remoteId = remoteId;
        this._creator = creator;
        this._type = type;
        this._verified = verified;
        this._userRoles=new Map();
        this._messages=new Map();
        this._name=null;
        this._teamId=null;
        this._access=[];
        this._accessRole=null;
        this._link=null;
    }
    /** @param {String} value */ set name(value) { this._name = value; }
    /** @param {String} value */ set teamId(value) { this._teamId = value; }
    /** @param {String[]} value */ set access(value) { this._access = value; }
    /** @param {String} value */ set accessRole(value) { this._accessRole = value; }
    /** @param {String} value */ set link(value) { this._link = value; }
    /** @returns {String} */ get id() { return this._id; }
    /** @returns {String} */ get remoteId() { return this._remoteId; }
    /** @returns {String} */ get creator() { return this._creator; }
    /** @returns {String} */ get type() { return this._type; }
    /** @returns {String} */ get verified() { return this._verified; }
    /** @returns {Map<String, String>} */ get userRoles() { return this._userRoles; }
    /** @returns {Map<String, Message>} */ get messages() { return this._messages; }
    /** @returns {String} */ get name() { return this._name; }
    /** @returns {String} */ get teamId() { return this._teamId; }
    /** @returns {String[]} */ get access() { return this._access; }
    /** @returns {String} */ get accessRole() { return this._accessRole; }
    /** @returns {String} */ get link() { return this._link; }
    /** @returns {String|null} */
    getPicturePath(){
        if(this.type === "ONE_TO_ONE"){
            for (let userid of this.userRoles.keys()) {
                let user=ChatExportAccess.cea.getUser(userid);
                if(user!=null && !user.isSelf)
                    return user.picture.filename;
            }
        }
        return null;
    }
    /** @returns {string} */
    getShort(){
        let realname=this.getName();
        if(realname.length>1)
            return realname.substr(0,2).toUpperCase();
        else
            return realname.toUpperCase();
    }
    /** @returns {String} */
    getName(){
        if(this.name!=null)
            return this.name;
        if(this.type === "ONE_TO_ONE"){
            for (let userid of this.userRoles.keys()) {
                let user=ChatExportAccess.cea.getUser(userid);
                if(user!=null && !user.isSelf)
                    return user.name;
            }
        }
        return "???";
    }
}

class MessageLoader{
    /** @type {Message[]} */ _messages;
    /** @type {Number} */ _currentMessage;
    /**
     * @param {Conversation} conversation
     */
    constructor(conversation){
        this._messages=Array.from(conversation.messages.values());
        this._currentMessage=this._messages.length-1;
        this._messages.sort(function (o1,o2){o1.compare(o2);});
    }
    /** @returns {null|Message} the next message */
    get(){
        if (this._currentMessage < 0)
            return null;
        return this._messages[this._currentMessage--];
    }
}

class Message{
    /** @type {String} */ _id;
    /** @type {String} */ _type;
    /** @type {String} */ _userId;
    /** @type {String} */ _state;
    /** @type {Date} */ _time;
    /** @type {MessageContent[]} */ _contents;
    /** @type {MessageProto[]} */ _protos;
    /** @type {Date} */ _localTime;
    /** @type {MessageError} */ _error;
    /** @type {Boolean} */ _isFirstMessage;
    /** @type {String[]} */ _members;
    /** @type {String} */ _recipient;
    /** @type {Date} */ _editTime;
    /** @type {Duration} */ _ephemeral;
    /** @type {Date} */ _expiryTime;
    /** @type {Duration} */ _duration;
    /** @type {String} */ _assetId;
    /** @type {Quote} */ _quote;

    /**
     * @param {String} id
     * @param {String} type
     * @param {String} userid
     * @param {String} state
     * @param {Date} time
     */
    constructor(id, type, userid, state, time) {
        this._id=id;
        this._type=type;
        this._userId=userid;
        this._state=state;
        this._time=time;
        this._contents=[];
        this._protos=[];
        this._localTime=null;
        this._error=null;
        this._isFirstMessage=false;
        this._members=[];
        this._recipient=null;
        this._editTime=null;
        this._ephemeral=null;
        this._expiryTime=null;
        this._duration=null;
        this._assetId=null;
        this._quote=null;
    }

    /** @returns {String} */ get id() {return this._id;}
    /** @returns {String} */ get type() {return this._type;}
    /** @returns {String} */ get userId() {return this._userId;}
    /** @returns {String} */ get state() {return this._state;}
    /** @returns {Date} */ get time() {return this._time;}
    /** @returns {Date} */ get localTime() {return this._localTime;}
    /** @param {Date} value */ set localTime(value) {this._localTime = value;}
    /** @returns {MessageError} */ get error() {return this._error;}
    /** @param {MessageError} value */ set error(value) {this._error = value;}
    /** @returns {Boolean} */ get isFirstMessage() {return this._isFirstMessage;}
    /** @param {Boolean} value */ set isFirstMessage(value) {this._isFirstMessage = value;}
    /** @returns {String} */ get recipient() {return this._recipient;}
    /** @param {String} value */ set recipient(value) {this._recipient = value;}
    /** @returns {Date} */ get editTime() {return this._editTime;}
    /** @param {Date} value */ set editTime(value) {this._editTime = value;}
    /** @returns {Duration} */ get ephemeral() {return this._ephemeral;}
    /** @param {Duration} value */ set ephemeral(value) {this._ephemeral = value;}
    /** @returns {Date} */ get expiryTime() {return this._expiryTime;}
    /** @param {Date} value */ set expiryTime(value) {this._expiryTime = value;}
    /** @returns {Duration} */ get duration() {return this._duration;}
    /** @param {Duration} value */ set duration(value) {this._duration = value;}
    /** @returns {String} */ get assetId() {return this._assetId;}
    /** @param {String} value */ set assetId(value) {this._assetId = value;}
    /** @returns {Quote} */ get quote() {return this._quote;}
    /** @param {Quote} value */ set quote(value) {this._quote = value;}
    /** @returns {MessageContent[]} */ get contents() {return this._contents;}
    /** @returns {String[]} */ get members() {return this._members;}
    /** @returns {MessageProto[]} */ get protos() {return this._protos;}

    /**
     * @param {Message} other
     * @returns {number}
     */
    compare(other){
        return this.time - other.time;
    }
}

class MessageError{
    /** @type {String} */ _clientId;
    /** @type {Number} */ _errorCode;
    /**
     * @param {String} clientId
     * @param {Number} errorCode
     */
    constructor(clientId, errorCode) {
        this._clientId=clientId;
        this._errorCode=errorCode;
    }
    /** @returns {String} */ get clientId() {return this._clientId;}
    /** @returns {Number} */ get errorCode() {return this._errorCode;}
}

class Duration{
    /** @type {Number} */ _length;
    /** @type {String} */ _timeUnit;
    /**
     * @param {Number} length
     * @param {String} timeUnit
     */
    constructor(length, timeUnit){
        this._length=length;
        this._timeUnit=timeUnit;
    }
    /** @returns {Number} */ get length(){return this._length;}
    /** @returns {String} */ get timeUnit(){return this._timeUnit;}
}

class Quote{
    /** @type {String} */ _msgId;
    /** @type {Boolean} */ _validity;
    /**
     * @param {String} msgId
     * @param {Boolean} validity
     */
    constructor(msgId, validity){
        this._msgId=msgId;
        this._validity=validity;
    }
    /** @returns {String} */ get msgId(){return this._msgId;}
    /** @returns {Boolean} */ get validity(){return this._validity;}
}

class MessageContent{
    /** @type {String} */ _type;
    /** @type {String} */ _content;
    /** @type {RichMedia} */ _richMedia;
    /** @type {OpenGraph} */ _openGraph;
    /** @type {String} */ _assetId;
    /** @type {Mention[]} */ _mentions;
    /** @type {Number} */ _width;
    /** @type {Number} */ _height;
    /**
     * @param {String} type
     * @param {String} content
     */
    constructor(type, content) {
        this._type=type;
        this._content=content;
        this._richMedia=null;
        this._openGraph=null;
        this._assetId=null;
        this._width=0;
        this._height=0;
        this._mentions=[];
    }

    /** @returns {String} */ get type() {return this._type;}
    /** @returns {String} */ get content() {return this._content;}
    /** @returns {RichMedia} */ get richMedia() {return this._richMedia;}
    /** @param {RichMedia} value */ set richMedia(value) {this._richMedia = value;}
    /** @returns {OpenGraph} */ get openGraph() {return this._openGraph;}
    /** @param {OpenGraph} value */ set openGraph(value) {this._openGraph = value;}
    /** @returns {String} */ get assetId() {return this._assetId;}
    /** @param {String} value */ set assetId(value) {this._assetId = value;}
    /** @returns {Number} */ get width() {return this._width;}
    /** @param {Number} value */ set width(value) {this._width = value;}
    /** @returns {Number} */ get height() {return this._height;}
    /** @param {Number} value */ set height(value) {this._height = value;}
    /** @returns {Mention[]} */ get mentions() {return this._mentions;}
}

class Mention{
    /** @type {Number} */ _start;
    /** @type {Number} */ _length;
    /** @type {String} */ _userId;
    /**
     * @param {Number} start
     * @param {Number} length
     */
    constructor(start, length) {
        this._start=start;
        this._length=length;
        this._userId=null;
    }
    /** @returns {Number} */ get start() {return this._start;}
    /** @returns {Number} */ get length() {return this._length;}
    /** @returns {String} */ get userId() {return this._userId;}
    /** @param {String} value */ set userId(value) {this._userId = value;}
}

class OpenGraph{
    /** @type {String} */ _title;
    /** @type {String} */ _description;
    /** @type {String} */ _tpe;
    /** @type {String} */ _permanentUrl;
    /** @type {String} */ _image;
    /**
     * @param {String} title
     * @param {String} description
     * @param {String} tpe
     */
    constructor(title, description, tpe) {
        this._title=title;
        this._description=description;
        this._tpe=tpe;
        this._permanentUrl=null;
        this._image=null;
    }
    /** @returns {String} */ get title() {return this._title;}
    /** @returns {String} */ get description() {return this._description;}
    /** @returns {String} */ get tpe() {return this._tpe;}
    /** @returns {String} */ get permanentUrl() {return this._permanentUrl;}
    /** @param {String} value */ set permanentUrl(value) {this._permanentUrl = value;}
    /** @returns {String} */ get image() {return this._image;}
    /** @param {String} value */ set image(value) {this._image = value;}
}

class RichMedia{
    /** @type {String} */ _kind;
    /** @type {String} */ _provider;
    /** @type {String} */ _title;
    /** @type {String} */ _linkUrl;
    /** @type {Artist} */ _artist;
    /** @type {Number} */ _duration;
    /** @type {String} */ _artwork;
    /** @type {Number} */ _expires;
    /** @type {RichMedia[]} */ _tracks;
    /** @type {Boolean} */ _streamable;
    /** @type {String} */ _streamUrl;
    /** @type {String} */ _previewUrl;
    /**
     * @param {String} kind
     * @param {String} provider
     * @param {String} title
     * @param {String} linkUrl
     */
    constructor(kind, provider, title, linkUrl) {
        this._kind=kind;
        this._provider=provider;
        this._title=title;
        this._linkUrl=linkUrl;
        this._artist=null;
        this._duration=null;
        this._artwork=null;
        this._expires=null;
        this._tracks=[];
        this._streamable=null;
        this._streamUrl=null;
        this._previewUrl=null;
    }
    /** @returns {String} */ get kind() {return this._kind;}
    /** @returns {String} */ get provider() {return this._provider;}
    /** @returns {String} */ get title() {return this._title;}
    /** @returns {String} */ get linkUrl() {return this._linkUrl;}
    /** @returns {Artist} */ get artist() {return this._artist;}
    /** @param {Artist} value */ set artist(value) {this._artist = value;}
    /** @returns {Number} */ get duration() {return this._duration;}
    /** @param {Number} value */ set duration(value) {this._duration = value;}
    /** @returns {String} */ get artwork() {return this._artwork;}
    /** @param {String} value */ set artwork(value) {this._artwork = value;}
    /** @returns {Number} */ get expires() {return this._expires;}
    /** @param {Number} value */ set expires(value) {this._expires = value;}
    /** @returns {RichMedia[]} */ get tracks() {return this._tracks;}
    /** @returns {Boolean} */ get streamable() {return this._streamable;}
    /** @param {Boolean} value */ set streamable(value) {this._streamable = value;}
    /** @returns {String} */ get streamUrl() {return this._streamUrl;}
    /** @param {String} value */ set streamUrl(value) {this._streamUrl = value;}
    /** @returns {String} */ get previewUrl() {return this._previewUrl;}
    /** @param {String} value */ set previewUrl(value) {this._previewUrl = value;}
}

class Artist{
    /** @type {String} */ _name;
    /** @type {String} */ _avatar;
    /**
     * @param {String} name
     */
    constructor(name) {
        this._name=name;
        this._avatar=null;
    }
    /** @returns {String} */ get name() {return this._name;}
    /** @returns {String} */ get avatar() {return this._avatar;}
    /** @param {String} value */ set avatar(value) {this._avatar = value;}
}

class MessageProto{
    static TYPE_ASSET="asset";
    static TYPE_CALLING="calling";
    static TYPE_CLEARED="cleared";
    static TYPE_CLIENT_ACTION="clientaction";
    static TYPE_DELETED="deleted";
    static TYPE_EDITED="edited";
    static TYPE_EXTERNAL="external";
    static TYPE_HIDDEN="hidden";
    static TYPE_IMAGE="image";
    static TYPE_KNOCK="knock";
    static TYPE_LAST_READ="lastread";
    static TYPE_REACTION="reaction";
    static TYPE_TEXT="text";
    static TYPE_LOCATION="location";
    static TYPE_CONFIRMATION="confirmation";
    static TYPE_AVAILABILITY="availability";
    static TYPE_COMPOSITE="composite";
    static TYPE_BUTTON_ACTION="buttonaction";
    static TYPE_BUTTON_ACTION_CONFIRMATION="buttonactionconfirmation";
    static TYPE_DATA_TRANSFER="datatransfer";
    static TYPE_UNKNOWN="debug_data";

    /** @type {String} */ _type;
    /** @param {String} type */
    constructor(type) {
        this._type=type;
    }
}

class ProtoExpireable extends MessageProto{
    /** @type {Number} */ _expireMillis;
    constructor(type){
        super(type);
        this._expireMillis=null;
    }
    /** @returns {Number} */ get expireMillis() {return this._expireMillis;}
    /** @param {Number} value */ set expireMillis(value) {this._expireMillis = value;}
}

class ProtoAsset extends ProtoExpireable{
    /** @type {String} */ _mimeType;
    /** @type {String} */ _name;
    /** @type {Number} */ _size;
    /** @type {String} */ _filepath;
    /** @type {Metadata} */ _metadata;
    /**
     * @param {String} mimeType
     * @param {String} name
     * @param {Number} size
     */
    constructor(mimeType, name, size){
        super(MessageProto.TYPE_ASSET);
        this._mimeType=mimeType;
        this._name=name;
        this._size=size;
        this._filepath=null;
        this._metadata=null;
    }

    /** @returns {String} */ get mimeType() {return this._mimeType;}
    /** @returns {String} */ get name() {return this._name;}
    /** @returns {Number} */ get size() {return this._size;}
    /** @returns {String} */ get filepath() {return this._filepath;}
    /** @param {String} value */ set filepath(value) {this._filepath = value;}
    /** @returns {Metadata} */ get metadata() {return this._metadata;}
    /** @param {Metadata} value */ set metadata(value) {this._metadata = value;}
}

class Metadata{
    static TYPE_AUDIO="AUDIO";
    static TYPE_IMAGE="IMAGE";
    static TYPE_VIDEO="VIDEO";
    static TYPE_UNKNOWN="UNKNOWN";

    /** @type {String} */ _type;
    /** @param {String} type */
    constructor(type){
        this._type=type;
    }

    /** @returns {String} */ get type() { return this._type; }
}

class MetadataAudio extends Metadata{
    /** @type {Number} */ _durationMillis;
    /** @type {Number[]} */ _normalizedLoudness;

    /**
     *  @param {Number} duration
     *  @param {Number[]} normalizedLoudness
     *  */
    constructor(duration, normalizedLoudness){
        super(Metadata.TYPE_AUDIO);
        this._durationMillis=duration;
        this._normalizedLoudness=normalizedLoudness;
    }
    /** @returns {Number} */ get duration() {return this._duration;}
    /** @returns {Number[]} */ get normalizedLoudness() {return this._normalizedLoudness;}
}

class MetadataImage extends Metadata{
    /** @type {Number} */ _width;
    /** @type {Number} */ _height;
    /** @type {String} */ _tag;

    /**
     *  @param {Number} width
     *  @param {Number} height
     *  @param {String} tag
     *  */
    constructor(width, height, tag){
        super(Metadata.TYPE_IMAGE);
        this._width=width;
        this._height=height;
        this._tag=tag;
    }
    /** @returns {Number} */ get width() {return this._width;}
    /** @returns {Number} */ get height() {return this._height;}
    /** @returns {String} */ get tag() {return this._tag;}
}

class MetadataVideo extends Metadata{
    /** @type {Number} */ _durationMillis;
    /** @type {Number} */ _width;
    /** @type {Number} */ _height;

    /**
     *  @param {Number} duration
     *  @param {Number} width
     *  @param {Number} height
     *  */
    constructor(duration, width, height){
        super(Metadata.TYPE_VIDEO);
        this._durationMillis=duration;
        this._width=width;
        this._height=height;
    }
    /** @returns {Number} */ get duration() {return this._duration;}
    /** @returns {Number} */ get width() {return this._width;}
    /** @returns {Number} */ get height() {return this._height;}
}

class MetadataUnknown extends Metadata{
    /** @type {String} */ _data;
    /** @param {String} data */
    constructor(data){
        super(Metadata.TYPE_UNKNOWN);
    }
    /** @returns {String} */ get data() {return this._data;}
}

class ProtoCalling extends MessageProto{
    /** @type {String} */ _data;
    /** @param {String} data */
    constructor(data){
        super(MessageProto.TYPE_CALLING);
    }
    /** @returns {String} */ get data() {return this._data;}
}

class ProtoCleared extends MessageProto{
    /** @type {Date} */ _timestamp;
    constructor(){
        super(MessageProto.TYPE_CLEARED);
    }
    /** @returns {Date} */ get timestamp() {return this._timestamp;}
    /** @param {Date} value */ set timestamp(value) {this._timestamp = value;}
}

class ProtoClientAction extends MessageProto{
    /** @type {String} */ _clientAction;
    /** @param {String} clientAction */
    constructor(clientAction){
        super(MessageProto.TYPE_CLIENT_ACTION);
        this._clientAction=clientAction;
    }
    /** @returns {String} */ get clientAction() {return this._clientAction;}
}

class ProtoDeleted extends MessageProto{
    /** @type {String} */ _messageId;
    /** @param {String} messageId */
    constructor(messageId){
        super(MessageProto.TYPE_DELETED);
        this._messageId=messageId;
    }
    /** @returns {String} */ get messageId() {return this._messageId;}
}

class ProtoEdited extends MessageProto{ // NOT SUPPORTED
    /** @type {String} */ _replacingMessageId;
    /** @type {ProtoText} */ _text;
    /** @type {ProtoComposite} */ _composite;
    /** @param {String} replacingMessageId */
    constructor(replacingMessageId){
        super(MessageProto.TYPE_EDITED);
        this._replacingMessageId=replacingMessageId;
        this._text=null;
        this._composite=null;
    }
    /** @returns {String} */ get replacingMessageId() {return this._replacingMessageId;}
    /** @returns {ProtoText} */ get text() {return this._text;}
    /** @param {ProtoText} value */ set text(value) {this._text = value;}
    /** @returns {ProtoComposite} */ get composite() {return this._composite;}
    /** @param {ProtoComposite} value */ set composite(value) {this._composite = value;}
}

class ProtoExternal extends MessageProto{
    /** @type {String} */ _encryption;
    /** @type {String} */ _otrKey;
    /** @type {String} */ _sha256;
    /**
     * @param {String} encryption
     * @param {String} otrKey
     * @param {String} sha256
     */
    constructor(encryption, otrKey, sha256){
        super(MessageProto.TYPE_EXTERNAL);
        this._encryption=encryption;
        this._otrKey=otrKey;
        this._sha256=sha256;
    }

    /** @returns {String} */ get encryption() {return this._encryption;}
    /** @returns {String} */ get otrKey() {return this._otrKey;}
    /** @returns {String} */ get sha256() {return this._sha256; }
}

class ProtoHidden extends MessageProto{
    /** @type {String} */ _messageId;
    /** @param {String} messageId */
    constructor(messageId){
        super(MessageProto.TYPE_HIDDEN);
        this._messageId=messageId;
    }
    /** @returns {String} */ get messageId() {return this._messageId;}
}

class ProtoImage extends ProtoExpireable{
    /** @type {String} */ _mimeType;
    /** @type {String} */ _tag;
    /** @type {Number} */ _width;
    /** @type {Number} */ _height;
    /** @type {Number} */ _originalWidth;
    /** @type {Number} */ _originalHeight;
    /** @type {Number} */ _size;
    /** @type {String} */ _mac;
    /** @type {String} */ _macKey;
    /** @type {String} */ _otrKey;
    /** @type {String} */ _sha256;
    /**
     * @param {String} mimeType
     * @param {String} tag
     * @param {Number} width
     * @param {Number} height
     * @param {Number} originalWidth
     * @param {Number} originalHeight
     * @param {Number} size
     * @param {String} mac
     * @param {String} macKey
     * @param {String} otrKey
     * @param {String} sha256
     */
    constructor(mimeType, tag, width, height, originalWidth, originalHeight, size, mac, macKey, otrKey, sha256){
        super(MessageProto.TYPE_IMAGE);
        this._mimeType=mimeType;
        this._tag=tag;
        this._width=width;
        this._height=height;
        this._originalWidth=originalWidth;
        this._originalHeight=originalHeight;
        this._size=size;
        this._mac=mac;
        this._macKey=macKey;
        this._otrKey=otrKey;
        this._sha256=sha256;
    }

    /** @returns {String} */ get mimeType() {return this._mimeType;}
    /** @returns {String} */ get tag() {return this._tag;}
    /** @returns {Number} */ get width() {return this._width;}
    /** @returns {Number} */ get height() {return this._height;}
    /** @returns {Number} */ get originalWidth() {return this._originalWidth;}
    /** @returns {Number} */ get originalHeight() {return this._originalHeight;}
    /** @returns {Number} */ get size() {return this._size;}
    /** @returns {String} */ get mac() {return this._mac;}
    /** @returns {String} */ get macKey() {return this._macKey;}
    /** @returns {String} */ get otrKey() {return this._otrKey;}
    /** @returns {String} */ get sha256() {return this._sha256;}
}

class ProtoKnock extends ProtoExpireable{
    /** @type {Boolean} */ _hotKnock;
    constructor(){
        super(MessageProto.TYPE_KNOCK);
        this._hotKnock=null;
    }
    /** @returns {Boolean} */ get hotKnock() {return this._hotKnock;}
    /** @param {Boolean} value */ set hotKnock(value) {this._hotKnock = value;}
}

class ProtoLastRead extends MessageProto{
    /** @type {Date} */ _timestamp;
    /** @param {Date} timestamp */
    constructor(timestamp){
        super(MessageProto.TYPE_LAST_READ);
        this._timestamp=timestamp;
    }
    /** @returns {Date} */ get timestamp() {return this._timestamp;}
}

class ProtoReaction extends MessageProto{
    /** @type {String} */ _emoji;
    /** @type {String} */ _messageId;
    /**
     * @param {String} emoji
     * @param {String} messageId
     */
    constructor(emoji, messageId){
        super(MessageProto.TYPE_REACTION);
        this._emoji=emoji;
        this._messageId=messageId;
    }
    /** @returns {String} */ get emoji() {return this._emoji;}
    /** @returns {String} */ get messageId() {return this._messageId;}
}

class ProtoText extends ProtoExpireable{
    /** @type {String} */ _content;
    /** @type {String} */ _quote;
    /** @type {Mention[]} */ _mentions;
    /** @type {LinkPreview[]} */ _linkPreviews;

    /** @param {String} content */
    constructor(content){
        super(MessageProto.TYPE_TEXT);
        this._content=content;
        this._quote=null;
        this._mentions=[];
        this._linkPreviews=[];
    }
    /** @returns {String} */ get content() {return this._content;}
    /** @returns {String} */ get quote() { return this._quote; }
    /** @param {String} value */ set quote(value) { this._quote = value; }
    /** @returns {Mention[]} */ get mentions() { return this._mentions; }
    /** @returns {LinkPreview[]} */ get linkPreviews() { return this._linkPreviews; }
}

class LinkPreview{
    /** @type {String} */ _permanentUrl;
    /** @type {String} */ _url;
    /** @type {String} */ _title;
    /** @type {String} */ _summary;
    /** @type {Number} */ _urlOffset;
    /** @type {ProtoAsset} */ _image;
    /** @type {Tweet} */ _tweet;

    /**
     * @param {String} permanentUrl
     * @param {String} url
     * @param {String} title
     * @param {String} summary
     * @param {Number} urlOffset
     */
    constructor(permanentUrl, url ,title, summary, urlOffset){
        this._permanentUrl=permanentUrl;
        this._url=url;
        this._title=title;
        this._summary=summary;
        this._urlOffset=urlOffset;
        this._image=null;
        this._tweet=null;
    }
    /** @returns {String} */ get permanentUrl() {return this._permanentUrl;}
    /** @returns {String} */ get url() {return this._url;}
    /** @returns {String} */ get title() {return this._title;}
    /** @returns {String} */ get summary() {return this._summary;}
    /** @returns {Number} */ get urlOffset() {return this._urlOffset;}
    /** @returns {ProtoAsset} */ get image() {return this._image;}
    /** @returns {Tweet} */ get tweet() {return this._tweet;}
}

class Tweet{
    /** @type {String} */ _author;
    /** @type {String} */ _username;
    /**
     * @param {String} author
     * @param {String} username
     */
    constructor(author, username){
        this._author=author;
        this._username=username;
    }
    /** @returns {String} */ get author() {return this._author;}
    /** @returns {String} */ get username() {return this._username;}

}

class ProtoLocation extends ProtoExpireable{
    /** @type {Number} */ _latitude;
    /** @type {Number} */ _longitude;
    /** @type {String} */ _name;
    /** @type {Number} */ _zoom;
    /**
     * @param {Number} latitude
     * @param {Number} longitude
     * @param {String} name
     * @param {Number} zoom
     */
    constructor(latitude, longitude, name, zoom){
        super(MessageProto.TYPE_LOCATION);
        this._latitude=latitude;
        this._longitude=longitude;
        this._name=name;
        this._zoom=zoom;
    }
    /** @returns {Number} */ get latitude() {return this._latitude;}
    /** @returns {Number} */ get longitude() {return this._longitude;}
    /** @returns {String} */ get name() {return this._name;}
    /** @returns {Number} */ get zoom() {return this._zoom;}
}

class ProtoConfirmation extends MessageProto{
    /** @type {String} */ _type;
    /** @type {String[]} */ _messageIds;
    /**
     * @param {String} type
     */
    constructor(type){
        super(MessageProto.TYPE_CONFIRMATION);
        this._type=type;
        this._messageIds=[];
    }
    /** @returns {String} */ get type() {return this._type;}
    /** @returns {String[]} */ get messageIds() {return this._messageIds;}
}

class ProtoAvailability extends MessageProto{
    /** @type {String} */ _availability;
    /** @param {String} availability */
    constructor(availability){
        super(MessageProto.TYPE_AVAILABILITY);
        this._availability=availability;
    }
    /** @returns {String} */ get availability() {return this._availability;}
}

class ProtoComposite extends MessageProto{ // NOT SUPPORTED
    /** @type {ProtoText} */ _text;
    /** @type {String} */ _buttonId;
    /** @type {String} */ _buttonText;

    constructor(){
        super(MessageProto.TYPE_COMPOSITE);
        this._text=null;
        this._buttonId=null;
        this._buttonText=null;
    }

    /** @returns {ProtoText} */ get text() {return this._text;}
    /** @param {ProtoText} value */ set text(value) {this._text = value;}
    /** @returns {String} */ get buttonId() {return this._buttonId;}
    /** @param {String} value */ set buttonId(value) {this._buttonId = value;}
    /** @returns {String} */ get buttonText() {return this._buttonText;}
    /** @param {String} value */ set buttonText(value) {this._buttonText = value;}
}

class ProtoButtonAction extends MessageProto{
    /** @type {String} */ _buttonId;
    /** @type {String} */ _refMessageId;
    /**
     * @param {String} buttonId
     * @param {String} refMessageId
     */
    constructor(buttonId, refMessageId){
        super(MessageProto.TYPE_BUTTON_ACTION);
        this._buttonId=buttonId;
        this._refMessageId=refMessageId;
    }
    /** @returns {String} */ get buttonId() {return this._buttonId;}
    /** @returns {String} */ get refMessageId() {return this._refMessageId;}
}

class ProtoButtonActionConfirmation extends MessageProto{
    /** @type {String} */ _buttonId;
    /** @type {String} */ _refMessageId;
    /**
     * @param {String} buttonId
     * @param {String} refMessageId
     */
    constructor(buttonId, refMessageId){
        super(MessageProto.TYPE_BUTTON_ACTION_CONFIRMATION);
        this._buttonId=buttonId;
        this._refMessageId=refMessageId;
    }
    /** @returns {String} */ get buttonId() {return this._buttonId;}
    /** @returns {String} */ get refMessageId() {return this._refMessageId;}
}

class ProtoDataTransfer extends MessageProto{
    /** @type {String} */ _transactionId;
    /** @param {String} transactionId */
    constructor(transactionId){
        super(MessageProto.TYPE_DATA_TRANSFER);
        this._transactionId=transactionId;
    }
    /** @returns {String} */ get transactionId() {return this._transactionId;}
}

class ProtoUnknown extends MessageProto{
    /** @type {String} */ _data;
    /** @param {String} data */
    constructor(data){
        super(MessageProto.TYPE_UNKNOWN);
        this._data=data;
    }
    /** @returns {String} */ get data() {return this._data;}
}