const DATA_PATH="data/";
const MEDIA_PATH=DATA_PATH+"media/";
const PROFILE_PATH=DATA_PATH+"profileData/";

class ChatExportAccess {

    /** @type {ChatExportAccess} */
    static cea;

    /**
     * @param {String} data - the chats.xml content
     */
    constructor(data) {
        ChatExportAccess.cea=this;
        this.xmlDoc=new DOMParser().parseFromString(data,"text/xml");
        this.users=new Map();
        this.conversations=new Map();
        this.loadUsers();
        this.loadConversations();
    }

    loadUsers(){
        let userselem=ChatExportAccess.getByXPath("/chatexport/users").iterateNext();
        if(userselem!==null){
            for (let userelem of userselem.childNodes) {
                if(userelem.nodeType===1){
                    /** @type {User} */
                    let user=new User(
                        this.getTextContent(userelem,"userid"),
                        this.getTextContent(userelem,"name"),
                        parseInt(this.getTextContent(userelem,"accent_color")));
                    this.doWithTextContentIfExists(userelem,"username",(s)=>user.username=s);
                    this.doWithTextContentIfExists(userelem,"teamid",(s)=>user.teamId=s);
                    this.doWithTextContentIfExists(userelem,"email",(s)=>user.email=s);
                    this.doWithTextContentIfExists(userelem,"phone",(s)=>user.phone=s);
                    this.doWithTextContentIfExists(userelem,"trackingid",(s)=>user.trackingId=s);
                    this.doWithTextContentIfExists(userelem,"userfields",(s)=>user.userFields=s);
                    this.doWithTextContentIfExists(userelem,"permission",(s)=>user.permission=s);
                    this.doWithElemIfExists(userelem,"picture",(p)=>user.picture=this.parseProfilePicture(p));
                    this.doWithAttributeIfExists(userelem,"isSelf", (a)=>{if(a==="true"){user.isSelf=true}});
                    this.users.set(user.userId,user);
                }
            }
        }
    }

    loadConversations(){
        let convelems=ChatExportAccess.getByXPath("/chatexport/conversations").iterateNext();
        if(convelems!==null){
            for (let convelem of convelems.childNodes) {
                if(convelem.nodeType===1){
                    /** @type {Conversation} */
                    let conv=new Conversation(
                        this.getTextContent(convelem,"id"),
                        this.getTextContent(convelem,"remoteid"),
                        this.getTextContent(convelem,"creator"),
                        this.getTextContent(convelem,"convType"),
                        this.getTextContent(convelem,"verified"));
                    this.doWithElemIfExists(convelem,"userroles",urList=>{
                        for (let ur of urList.childNodes)
                            if(ur.nodeType===1) {
                                let userid = ur.getAttribute("userid");
                                let role = ur.getAttribute("role");
                                if (userid != null && role != null)
                                    conv.userRoles.set(userid, role);
                            }
                    });
                    this.doWithElemIfExists(convelem,"access",aList=>{
                        for (let at of aList.childNodes)
                            if(at.nodeType===1)
                                conv.access.push(at.textContent);
                    });
                    this.doWithTextContentIfExists(convelem,"name",(s)=>conv.name=s);
                    this.doWithTextContentIfExists(convelem,"teamid",(s)=>conv.teamId=s);
                    this.doWithTextContentIfExists(convelem,"accessrole",(s)=>conv.accessRole=s);
                    this.doWithTextContentIfExists(convelem,"link",(s)=>conv.link=s);
                    this.doWithElemIfExists(convelem,"messages",mList=>{
                        for(let msgElem of mList.childNodes)
                            if(msgElem.nodeType===1){
                                let res=this.loadMessage(msgElem);
                                conv.messages.set(res[0],res[1]);
                            }
                    });
                    this.conversations.set(conv.id,conv);
                }
            }
        }
    }

    /**
     * @param {Element} msgElem
     * @returns {(String|Message)[]}
     */
    loadMessage(msgElem){
        /** @type {Message} */
        let msg=new Message(
            this.getTextContent(msgElem,"id"),
            this.getTextContent(msgElem,"msg_type"),
            this.getTextContent(msgElem,"userid"),
            this.getTextContent(msgElem,"state"),
            new Date(this.getTextContent(msgElem,"time")));

        this.doWithTextContentIfExists(msgElem,"local_time",(s)=>msg.localTime=new Date(s));
        this.doWithTextContentIfExists(msgElem,"first_message",(s)=>msg.isFirstMessage=s==="true");
        this.doWithTextContentIfExists(msgElem,"recipient",(s)=>msg.recipient=s);
        this.doWithTextContentIfExists(msgElem,"edit_time",(s)=>msg.editTime=new Date(s));
        this.doWithTextContentIfExists(msgElem,"expiry_time",(s)=>msg.expiryTime=new Date(s));
        this.doWithTextContentIfExists(msgElem,"asset_id",(s)=>msg.assetId=s);

        this.doWithElemIfExists(msgElem,"error",(e)=>{
            msg.error=new MessageError(this.getTextContent(e,"client_id"),parseInt(this.getTextContent(e,"errorcode")));
        });
        this.doWithElemIfExists(msgElem,"members",(e)=>{
            for(let member of e.childNodes)
                if(member.nodeType===1)
                    msg.members.push(member.textContent);
        });
        this.doWithElemIfExists(msgElem,"ephemeral",(e)=>{
            msg.ephemeral=new Duration(parseInt(this.getTextContent(e,"length")),this.getTextContent(e,"timeunit"));
        });
        this.doWithElemIfExists(msgElem,"duration",(e)=>{
            msg.duration=new Duration(parseInt(this.getTextContent(e,"length")),this.getTextContent(e,"timeunit"));
        });
        this.doWithElemIfExists(msgElem,"quote",(e)=>{
            msg.quote=new Quote(e.textContent,e.getAttribute("validity")==="true");
        });

        this.doWithElemIfExists(msgElem,"contents",(e)=>{
            for(let content of e.childNodes)
                if(content.nodeType===1)
                    msg.contents.push(this.loadMessageContent(content));
        });
        this.doWithElemIfExists(msgElem,"protos",(e)=>{
            for(let proto of e.childNodes)
                if(proto.nodeType===1)
                    msg.protos.push(this.loadMessageProto(proto));
        });
        console.log(msg);
        return [msg.id,msg];
    }

    /**
     * @param {Element} content
     * @returns {MessageContent}
     */
    loadMessageContent(content){
        /** @type {MessageContent} */
        let msgc=new MessageContent(
            this.getTextContent(content,"type"),
            this.getTextContent(content,"content"));
        this.doWithElemIfExists(content,"rich_media",(e)=>{msgc.richMedia=this.loadRichMedia(e);});
        this.doWithElemIfExists(content,"open_graph",(e)=>{
            msgc.openGraph=new OpenGraph(
                this.getTextContent(e,"title"),
                this.getTextContent(e,"description"),
                this.getTextContent(e,"tpe")
            );
            this.doWithTextContentIfExists(e,"permanenturl",s=>{msgc.openGraph.permanentUrl=s});
            this.doWithTextContentIfExists(e,"image",s=>{msgc.openGraph.image=s});
        });
        this.doWithTextContentIfExists(content,"asset_id",s=>{msgc.assetId=s});
        this.doWithTextContentIfExists(content,"width",s=>{msgc.width=parseInt(s)});
        this.doWithTextContentIfExists(content,"height",s=>{msgc.height=parseInt(s)});
        this.doWithElemIfExists(content,"mentions",e=>{
            for(let mention of e.childNodes)
                if(mention.nodeType===1){
                    msgc.mentions.push(this.loadMention(mention));
                }
        });
        return msgc
    }

    /**
     * @param {Element} mention
     * @returns {Mention}
     */
    loadMention(mention){
        let ment=new Mention(
            parseInt(this.getTextContent(mention,"start")),
            parseInt(this.getTextContent(mention,"length"))
        );
        this.doWithTextContentIfExists(mention,"userid",s=>{ment.userId=s});
        return ment;
    }

    /**
     * @param {Element} richMedia
     * @returns {RichMedia}
     */
    loadRichMedia(richMedia){
        /** @type {RichMedia} */
        let rm=new RichMedia(
                this.getTextContent(richMedia,"kind"),
                this.getTextContent(richMedia,"provider"),
                this.getTextContent(richMedia,"title"),
                this.getTextContent(richMedia,"linkurl"));
        this.doWithTextContentIfExists(richMedia,"duration",(s)=>rm.duration=parseInt(s));
        this.doWithTextContentIfExists(richMedia,"artwork",(s)=>rm.artwork=s);
        this.doWithTextContentIfExists(richMedia,"expires",(s)=>rm.expires=parseInt(s));
        this.doWithTextContentIfExists(richMedia,"streamable",(s)=>rm.streamable=s==="true");
        this.doWithTextContentIfExists(richMedia,"streamurl",(s)=>rm.streamUrl=s);
        this.doWithTextContentIfExists(richMedia,"previewurl",(s)=>rm.previewUrl=s);
        this.doWithElemIfExists(richMedia, "artist",e=>{
            rm.artist=new Artist(this.getTextContent(e,"name"));
            this.doWithTextContentIfExists(e,"avatar",s=>rm.artist.avatar=s);
        });
        this.doWithElemIfExists(richMedia, "tracks",e=>{
            for(let track of e.childNodes)
                if(track.nodeType===1)
                    rm.tracks.push(this.loadRichMedia(track));
        });
        return rm;
    }

    /**
     * @param {Element} proto
     * @returns {MessageProto}
     */
    loadMessageProto(proto){
        for(let elem of proto.childNodes)
            if(elem.nodeType===1){
                switch(elem.tagName){
                    case MessageProto.TYPE_ASSET:
                        return this.loadAsset(elem);
                    case MessageProto.TYPE_CALLING:
                        return new ProtoCalling(elem.textContent);
                    case MessageProto.TYPE_CLEARED:
                        let pc=new ProtoCleared();
                        this.doWithAttributeIfExists(elem,"",s=>pc.timestamp=new Date(parseInt(s)));
                        return pc;
                    case MessageProto.TYPE_CLIENT_ACTION:
                        return new ProtoClientAction(elem.textContent);
                    case MessageProto.TYPE_DELETED:
                        return new ProtoDeleted(elem.textContent);
                    case MessageProto.TYPE_EDITED:
                        let edited=new ProtoEdited(
                            this.getTextContent(elem, "replacingMessageId")
                        );
                        this.doWithElemIfExists(elem,"text",e=>{edited.text=this.loadText(e)});
                        this.doWithElemIfExists(elem,"composite",e=>{edited.composite=this.loadComposite(e)});
                        return edited;
                    case MessageProto.TYPE_EXTERNAL:
                        return new ProtoExternal(
                            this.getTextContent(elem, "encryption"),
                            this.getTextContent(elem, "otrKey"),
                            this.getTextContent(elem, "sha256")
                        );
                    case MessageProto.TYPE_HIDDEN:
                        return new ProtoHidden(elem.textContent);
                    case MessageProto.TYPE_IMAGE:
                        let image=new ProtoImage(
                            this.getTextContent(elem, "mimeType"),
                            this.getTextContent(elem, "tag"),
                            parseInt(this.getTextContent(elem, "width")),
                            parseInt(this.getTextContent(elem, "height")),
                            parseInt(this.getTextContent(elem, "originalWidth")),
                            parseInt(this.getTextContent(elem, "originalHeight")),
                            parseInt(this.getTextContent(elem, "size")),
                            this.getTextContent(elem, "mac"),
                            this.getTextContent(elem, "macKey"),
                            this.getTextContent(elem, "otrKey"),
                            this.getTextContent(elem, "sha256")
                        );
                        this.doWithAttributeIfExists(elem,"expiremillis",s=>image.expireMillis=parseInt(s));
                        return image;
                    case MessageProto.TYPE_KNOCK:
                        let knock=new ProtoKnock();
                        this.doWithTextContentIfExists(elem, "hotknock", s=>knock.hotKnock=s===true);
                        this.doWithTextContentIfExists(elem, "expiremillis", s=>knock.expireMillis=parseInt(s));
                        return knock;
                    case MessageProto.TYPE_LAST_READ:
                        return new ProtoLastRead(new Date(parseInt(elem.textContent)));
                    case MessageProto.TYPE_REACTION:
                        return new ProtoReaction(
                            this.getTextContent(elem,"emoji"),
                            this.getTextContent(elem,"messageid")
                        );
                    case MessageProto.TYPE_TEXT:
                        return this.loadText(elem);
                    case MessageProto.TYPE_LOCATION:
                        let loc=new ProtoLocation(
                            parseInt(this.getTextContent(elem, "latitude")),
                            parseInt(this.getTextContent(elem, "longitude")),
                            this.getTextContent(elem, "name"),
                            parseInt(this.getTextContent(elem, "zoom"))
                        );
                        this.doWithAttributeIfExists(elem,"expiremillis",s=>loc.expireMillis=parseInt(s));
                        return loc;
                    case MessageProto.TYPE_CONFIRMATION:
                        let conf=new ProtoConfirmation(this.getTextContent(elem,"type"));
                        this.doWithElemIfExists(elem,"messageids",e=>{
                            for(let msgId of e.childNodes)
                                if(msgId.nodeType===1)
                                    conf.messageIds.push(msgId.textContent);
                        });
                        return conf;
                    case MessageProto.TYPE_AVAILABILITY:
                        return new ProtoAvailability(elem.textContent);
                    case MessageProto.TYPE_COMPOSITE:
                        return this.loadComposite(elem);
                    case MessageProto.TYPE_BUTTON_ACTION:
                        return new ProtoButtonAction(
                            this.getTextContent(elem,"buttonid"),
                            this.getTextContent(elem,"refmessageid")
                        );
                    case MessageProto.TYPE_BUTTON_ACTION_CONFIRMATION:
                        return new ProtoButtonActionConfirmation(
                            this.getTextContent(elem,"buttonid"),
                            this.getTextContent(elem,"refmessageid")
                        );
                    case MessageProto.TYPE_DATA_TRANSFER:
                        return new ProtoDataTransfer(elem.textContent);
                    case MessageProto.TYPE_UNKNOWN:
                        return new ProtoUnknown(elem.textContent);
                }
            }
        return null;
    }

    /**
     * @param {Element} elem
     * @returns {ProtoComposite}
     */
    loadComposite(elem){
        let comp=new ProtoComposite();
        this.doWithElemIfExists(elem,"text",e=>comp.text=this.loadText(e));
        this.doWithElemIfExists(elem,"button",e=>{
            this.doWithTextContentIfExists(e,"id",s=>comp.buttonId=s)
            this.doWithTextContentIfExists(e,"text",s=>comp.buttonText=s)
        });
        return comp;
    }

    /**
     * @param {Element} elem
     * @returns {ProtoText}
     */
    loadText(elem){
        let text=new ProtoText(this.getTextContent(elem,"content"));
        this.doWithTextContentIfExists(elem,"quote",s=>text.quote=s);
        this.doWithTextContentIfExists(elem, "expiremillis", s=>text.expireMillis=parseInt(s));
        this.doWithElemIfExists(elem,"mentions",e=>{
            for(let mention of e.childNodes)
                if(mention.nodeType===1){
                    text.mentions.push(this.loadMention(mention));
                }
        });
        this.doWithElemIfExists(elem,"linkpreviews",e=>{
            let lp=new LinkPreview(
                this.getTextContent(e,"permanenturl"),
                this.getTextContent(e,"url"),
                this.getTextContent(e,"title"),
                this.getTextContent(e,"summary"),
                parseInt(this.getTextContent(e,"urloffset"))
            );
            this.doWithElemIfExists(e,"image",e2=>{lp.image=this.loadAsset(e2)});
            this.doWithElemIfExists(e,"tweet",e2=>{
                lp.tweet=new Tweet(this.getTextContent(e2,"author"),this.getTextContent(e2,"username"));
            })
        });
        return text;
    }

    /**
     * @param {Element} elem
     * @returns {ProtoAsset}
     */
    loadAsset(elem){
        let asset=new ProtoAsset(
            this.getTextContent(elem,"mime_type"),
            this.getTextContent(elem,"name"),
            parseInt(this.getTextContent(elem,"size"))
        );
        this.doWithTextContentIfExists(elem,"filepath",s=>asset.filepath=s);
        this.doWithTextContentIfExists(elem, "expiremillis", s=>asset.expireMillis=parseInt(s));
        this.doWithElemIfExists(elem,"metadata",e=>{
            for(let metadata of e.childNodes)
                if(metadata.nodeType===1)
                    switch (metadata.tagName) {
                        case Metadata.TYPE_AUDIO:
                            return new MetadataAudio(
                                parseInt(this.getTextContent(metadata,"duration_in_millis")),
                                this.getTextContent(metadata,"normalized_loudness").split(",").map(s=>parseInt(s))
                            );
                        case Metadata.TYPE_IMAGE:
                            return new MetadataImage(
                                parseInt(this.getTextContent(metadata,"width")),
                                parseInt(this.getTextContent(metadata,"height")),
                                this.getTextContent(metadata,"tag")
                            );
                        case Metadata.TYPE_VIDEO:
                            return new MetadataVideo(
                                parseInt(this.getTextContent(metadata,"duration_in_millis")),
                                parseInt(this.getTextContent(metadata,"height")),
                                parseInt(this.getTextContent(metadata,"width"))
                            );
                        case Metadata.TYPE_UNKNOWN:
                            return new MetadataUnknown(metadata.textContent);
                    }
        });
        return asset;
    }

    /**
     * @param {Element} picture
     * @returns {ProfilePicture}
     */
    parseProfilePicture(picture){
        let profilePicture=new ProfilePicture(picture.textContent);
        let uploaded=picture.getAttribute("uploaded");
        if(uploaded!=null)
            profilePicture.uploaded=uploaded==="true";
        return profilePicture;
    }

    /**
     * @param {String} userId the user id
     * @returns {User} the user
     */
    getUser(userId){
        return this.users.get(userId);
    }

    /**
     * @returns {IterableIterator<User>} the users
     */
    getUsers(){
        return this.users.values();
    }

    /**
     * @param {String} convId the conversation id
     * @returns {Conversation} the conversation
     */
    getConversation(convId){
        return this.conversations.get(convId);
    }

    /**
     * @returns {IterableIterator<Conversation>} the conversations
     */
    getConversations(){
        return this.conversations.values();
    }

    /**
     * @param xPath - the XPath-Query
     * @param {Node} element - the element to start the search from
     * @param {Document} doc
     * @returns {XPathResult}
     */
    static getByXPath(xPath, element = ChatExportAccess.cea.xmlDoc, doc= ChatExportAccess.cea.xmlDoc){
        return doc.evaluate(xPath, element, null, XPathResult.ANY_TYPE, null);
    }

    /**
     * @callback elemCallback
     * @param {Element} element
     */

    /**
     * @param {Element} elem
     * @param {String} tag
     * @param {elemCallback} callback
     */
    doWithElemIfExists(elem, tag, callback){
        let tmp=this.getElem(elem, tag);
        if(tmp!=null)
            callback(tmp);
    }

    /**
     * @callback stringCallback
     * @param {String} string
     */

    /**
     * @param {Element} elem
     * @param {String} tag
     * @param {stringCallback} callback
     */
    doWithTextContentIfExists(elem, tag, callback){
        let tmp=this.getTextContent(elem, tag);
        if(tmp!=null)
            callback(tmp);
    }

    /**
     * @param {Element} elem
     * @param {String} name
     * @param {stringCallback} callback
     */
    doWithAttributeIfExists(elem, name, callback){
        let attr=elem.getAttribute(name);
        if(attr!=null)
            callback(attr);
    }
    /**
     * @param elem
     * @param tag
     * @returns {String|null}
     */
    getTextContent(elem, tag){
        let tmp=this.getElem(elem, tag);
        if(tmp!=null)
            return tmp.textContent;
        return null;
    }
    /**
     * @param elem
     * @param tag
     * @returns {Element|null}
     */
    getElem(elem, tag){
        elem.getElementsByTagName(tag);
        for (let child of elem.childNodes) {
            if(child.nodeType === 1){
                if(child.tagName === tag)
                    return child;
            }
        }
        return null;
    }
}