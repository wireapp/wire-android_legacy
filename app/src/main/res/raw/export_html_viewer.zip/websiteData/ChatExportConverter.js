class ChatExportConverter {
    /** @type {ChatExportAccess} */ _cea;
    /** @type {Conversation} */ _currentConversation;
    /**
     * @param {ChatExportAccess} chatExportAccess
     */
    constructor(chatExportAccess) {
        this._cea=chatExportAccess;
        this._currentConversation=null;
    }
    /**
     * @param {Conversation} conversation
     */
    setCurrentConversation(conversation){
        this._currentConversation=conversation;
    }
    /**
     * @param {User} user
     * @returns {string} the html code
     */
    createUserItem(user){
        return ('\
        <div class="left_item" data-id="'+user.userId+'" onclick="showUserDetails(\''+user.userId+'\', this);">'+
            this.getProfilePicture(user)+
            '<div class="user_item_info">\
            <div class="item_name">'+user.name+'</div>'+
                (user.username==null?"":
                '<div class="user_item_username">'+user.username+'</div>')
            +'</div>\
        </div>');
    }

    /**
     * @param {Conversation} conversation
     * @returns {string} the html code
     */
    createConversationItem(conversation) {
        let picturePath=conversation.getPicturePath();
        return ('\
        <div class="left_item" data-id="'+conversation.id+'" onclick="showConversation(\''+conversation.id+'\', this);">\
            <div class="item_profile_picture_container">'+
            (picturePath==null?
                '<div class="left_item_textpic">'+conversation.getShort()+'</div>':
                '<img src="'+picturePath+'" alt="'+conversation.getShort()+'">')
            +'</div>\
            <div class="item_name">'+conversation.getName()+'</div>'+
            '</div>');
    }

    /**
     * @param {Message} msg the message object
     * @param {Boolean} isQuote
     * @returns {string} the html code
     */
    createMessageItem(msg, isQuote= false){
        /** @type {null|String} */
        let item=null;
        let header=this.getMsgHeader(msg, isQuote);
        switch(msg.type){
            case "TEXT":
                item=this.generateTEXT(msg, header, isQuote);
                break;
            case "TEXT_EMOJI_ONLY":
                item=this.generateTEXT_EMOJI_ONLY(msg, header, isQuote);
                break;
            case "IMAGE_ASSET":
                item=this.generateIMAGE_ASSET(msg, header, isQuote);
                break;
            case "ANY_ASSET":
                item=this.generateANY_ASSET(msg, header, isQuote);
                break;
            case "VIDEO_ASSET":
                item=this.generateVIDEO_ASSET(msg, header, isQuote);
                break;
            case "AUDIO_ASSET":
                item=this.generateAUDIO_ASSET(msg, header, isQuote);
                break;
            case "RESTRICTED_FILE":
                item=this.generateRESTRICTED_FILE(msg);
                break;
            case "KNOCK":
                item=this.generateKNOCK(msg);
                break;
            case "MEMBER_JOIN":
                item=this.generateMEMBER_JOIN(msg);
                break;
            case "RICH_MEDIA":
                item=this.generateRICH_MEDIA(msg, header, isQuote);
                break;
            case "LOCATION":
                item=this.generateLOCATION(msg, header, isQuote);
                break;
            case "RECALLED":
                item=this.generateRECALLED(msg);
                break;
            case "MEMBER_LEAVE":
                item=this.generateMEMBER_LEAVE(msg);
                break;
            case "CONNECT_REQUEST":
                item=this.generateCONNECT_REQUEST(msg);
                break;
            case "CONNECT_ACCEPTED":
                item=this.generateCONNECT_ACCEPTED(msg);
                break;
            case "RENAME":
                item=this.generateRENAME(msg);
                break;
            case "MISSED_CALL":
                item=this.generateMISSED_CALL(msg);
                break;
            case "SUCCESSFUL_CALL":
                item=this.generateSUCCESSFUL_CALL(msg);
                break;
            case "OTR_ERROR":
                item=this.generateOTR_ERROR(msg);
                break;
            case "OTR_ERROR_FIXED":
                item=this.generateOTR_ERROR_FIXED(msg);
                break;
            case "OTR_IDENTITY_CHANGED":
                item=this.generateOTR_IDENTITY_CHANGED(msg);
                break;
            case "OTR_VERIFIED":
                item=this.generateOTR_VERIFIED(msg);
                break;
            case "OTR_UNVERIFIED":
                item=this.generateOTR_UNVERIFIED(msg);
                break;
            case "OTR_DEVICE_ADDED":
                item=this.generateOTR_DEVICE_ADDED(msg);
                break;
            case "OTR_MEMBER_ADDED":
                item=this.generateOTR_MEMBER_ADDED(msg);
                break;
            case "SESSION_RESET":
                item=this.generateSESSION_RESET(msg);
                break;
            case "STARTED_USING_DEVICE":
                item=this.generateSTARTED_USING_DEVICE(msg);
                break;
            case "HISTORY_LOST":
                item=this.generateHISTORY_LOST(msg);
                break;
            case "MESSAGE_TIMER":
                item=this.generateMESSAGE_TIMER(msg);
                break;
            case "READ_RECEIPTS_ON":
                item=this.generateREAD_RECEIPTS_ON(msg);
                break;
            case "READ_RECEIPTS_OFF":
                item=this.generateREAD_RECEIPTS_OFF(msg);
                break;
            case "COMPOSITE":
                item=this.generateCOMPOSITE(msg);
                break;
            case "UNKNOWN":
                item=this.generateUNKNOWN(msg);
                break;
        }
        if(item==null || item===""){
            return this.createMessageItemContent(msg, header, "<div class=\"missing_data\">The display of messages with type \""+msg.type+"\" is currently not supported!</div>", isQuote);
        }
        return item;
    }
    /**
     * @param {Message} msg
     * @param {String} header
     * @param {String} itemData
     * @param {Boolean} isQuote
     * @param {String} expiredText
     * @returns {string}
     */
    createMessageItemContent(msg, header, itemData= null, isQuote= false, expiredText="This message is expired"){
        let styleClass="";
        let expired=msg.expiryTime!=null&&msg.expiryTime<Date.now();
        if(expired){
            styleClass=" expired";
            itemData=this.getRandomStringOfText(expiredText);
            itemData=itemData.replace(/(?:\r\n|\r|\n)/g, '<br>');
        }
        return "<div class=\"message_item"+styleClass+"\">"+
                    header+
                    (itemData==null?"":
                        (isQuote?"":"<div class=\"message_item_content\">")+
                            "<div class=\"message_item_data\">"+itemData+"</div>"+
                            (isQuote?"":"<div class=\"message_item_right_space\"></div>")+
                        (isQuote?"":"</div>")
                    )+
                "</div>";
    }

    /**
     * @param {String} text
     * @returns {String} result text
     */
    getRandomStringOfText(text){
        let values='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result="";
        for(let i=0;i<text.length;i++){
            if(text.charAt(i).trim().length===0){
                result+=text.charAt(i);
            }else{
                result+=values[Math.floor(Math.random()*values.length)];
            }
        }
        return result;
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateUNKNOWN(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateCOMPOSITE(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateREAD_RECEIPTS_OFF(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateREAD_RECEIPTS_ON(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateMESSAGE_TIMER(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateHISTORY_LOST(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateSTARTED_USING_DEVICE(msg) {
        return this.getSalutationItem(msg, "started using a new device.");
    }

    /**
     * @param {Message} msg
     * @param {String} textMessage
     * @returns {string}
     */
    getSalutationItem(msg, textMessage){
        let user=this._cea.getUser(msg.userId);
        return this.createMessageItemContent(msg, this.getCustomHeader(msg,null,
            "<div class=\"message_header_content\"><b class=\"bold\">"+user.getSalutation()+"</b> "+textMessage+"</div>"),
            null, false, user.getSalutation()+" "+textMessage
        );
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateSESSION_RESET(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateOTR_MEMBER_ADDED(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateOTR_DEVICE_ADDED(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateOTR_UNVERIFIED(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateOTR_VERIFIED(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateOTR_IDENTITY_CHANGED(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateOTR_ERROR_FIXED(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateOTR_ERROR(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateSUCCESSFUL_CALL(msg) {
        return this.getCallItem(msg,["svg_green"]);
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateMISSED_CALL(msg) {
        return this.getCallItem(msg,["svg_red"]);
    }

    getCallItem(msg, styleClasses=[]){
        let user=this._cea.getUser(msg.userId);
        return this.createMessageItemContent(msg,
            this.getCustomHeader(msg,
                '<div class=\"message_header_icon\">' +
                    "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"8\" viewBox=\"0 0 20 8\" class=\""+styleClasses.join(" ")+"\">" +
                        "<path xmlns=\"http://www.w3.org/2000/svg\" d=\"M.6 2.7C2.2 1.2 6 0 9.7 0c3.8 0 7.6 1.2 9 2.7 1 .9.9 2.9 0 4.6l-.3.3H18A216 216 0 0 0 14 6c-.4-.1-.3-.1-.3-.5V3.4l-1-.2a13 13 0 0 0-6.2 0l-.9.2V6l-.4.2a155.4 155.4 0 0 0-3.8 1.5c-.4.1-.4.1-.6-.3-1-1.7-1-3.7-.2-4.6z\"></path>" +
                    "</svg>"+
                '</div>',
                "<div class=\"message_header_content\"><b class=\"bold\">"+user.getSalutation()+"</b> called</div>"),
            null, false, user.getSalutation()+" called"
        );
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateRENAME(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateCONNECT_ACCEPTED(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateCONNECT_REQUEST(msg) {
        let user=this._cea.getUser(msg.recipient);
        return this.getSalutationItem(msg, "would like to connect"+
                (user==null?"":" with <b class=\"bold\">"+user.name+"</b>")
                +".");
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateMEMBER_LEAVE(msg) {
        return this.getSalutationItem(msg, "leaved the conversation.");
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateRECALLED(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @param {String} header the message object
     * @param {Boolean} isQuote the message object
     * @returns {string} the html code
     */
    generateLOCATION(msg, header, isQuote) {
        let html="";
        this.runForAllProtos(msg,p=>{
            if(p instanceof ProtoLocation){
                // noinspection HtmlDeprecatedAttribute
                html+='<iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0" ' +
                        'src="https://maps.google.com/maps?q='+p.latitude+','+p.longitude+'&hl=es;z='+p.zoom+'&amp;output=embed"' +
                        '></iframe>';
            }
        });
        return this.createMessageItemContent(msg, header, html, isQuote);
    }

    /**
     * @param {Message} msg the message object
     * @param {String} header the message object
     * @param {Boolean} isQuote the message object
     * @returns {string} the html code
     */
    generateRICH_MEDIA(msg, header, isQuote) {
        let html="";
        this.runForAllContent(msg,c=>{
            html+=  "<div>"+
                        "<div>"+
                            this.getMention(c.mentions, c.content.replace(/(?:\r\n|\r|\n)/g, '<br>'))+
                        "</div>"+
                        "<div>";
                            if(c.type==="YOUTUBE"){
                                let id=c.richMedia.linkUrl.substring(c.richMedia.linkUrl.indexOf("=")+1);
                                html+='<iframe src="https://www.youtube-nocookie.com/embed/'+id+'?html5=1&amp;enablejsapi=0&amp;modestbranding=1&amp;rel=0" allowfullscreen="" frameborder="0"></iframe>';
                            }else if(c.type==="SPOTIFY"){
                                let regexp=/(?:.*?)\/\/(?:.*?)\/(.*?)\/(.*?)\?/g;
                                let res=regexp.exec(c.richMedia.linkUrl);
                                html+='<iframe src="https://embed.spotify.com/?uri=spotify%3A'+res[1]+'%3A'+res[2]+'" frameborder="0"></iframe>';
                            }else if(c.type==="SOUNDCLOUD"){
                                html+='<iframe src="https://w.soundcloud.com/player/?url='+c.richMedia.linkUrl+'&amp;visual=false&amp;show_comments=false&amp;buying=false&amp;show_playcount=false&amp;liking=false&amp;sharing=false&amp;hide_related=true" frameborder="0"></iframe>';
                            }else{
                                html+='<iframe src="'+c.richMedia.linkUrl+'" frameborder="0"></iframe>';
                            }
                        html+="</div>"+
                    "</div>";
        });
        return this.createMessageItemContent(msg, header, html, isQuote);
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateMEMBER_JOIN(msg) {
        return this.getSalutationItem(msg, "joined the conversation.");
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateKNOCK(msg) {
        let user=this._cea.getUser(msg.userId);
        return this.createMessageItemContent(msg,
            this.getCustomHeader(msg,
                '<div class=\"message_header_icon accent-color\" data-accent="'+user.accent_color+'">&#10043</div>',
                "<div class=\"message_header_content\"><b class=\"bold\">"+user.getSalutation()+"</b> pinged</div>"),
            null, false, user.getSalutation()+" pinged"
        );
    }

    /**
     * @param {Message} msg the message object
     * @returns {string} the html code
     */
    generateRESTRICTED_FILE(msg) {
        return "";
    }

    /**
     * @param {Message} msg the message object
     * @param {String} header the message object
     * @param {Boolean} isQuote the message object
     * @returns {string} the html code
     */
    generateAUDIO_ASSET(msg, header, isQuote) {
        let html="";
        this.runForAllProtos(msg,p=>{
            if(p instanceof ProtoAsset){
                if(p.filepath!=null){
                html+=  '<audio controls src="'+p.filepath+'" style="width:100%;">' +
                            '<p class="missing_data">Audio is not supported in your browser.<br>' +
                            'File "'+p.name+'" of type "'+p.mimeType+'" with size "'+this.formatBytes(p.size)+'" cannot be played.' +
                            '</p>'+
                        '</audio>'
                }else
                    html+='<div class="missing_data">Not exported file "'+p.name+'" of type "'+p.mimeType+'" with size "'+this.formatBytes(p.size)+'".</div>';
            }
        });
        return this.createMessageItemContent(msg, header, html, isQuote);
    }

    /**
     * @param {Message} msg the message object
     * @param {String} header the message object
     * @param {Boolean} isQuote the message object
     * @returns {string} the html code
     */
    generateVIDEO_ASSET(msg, header, isQuote) {
        let html="";
        this.runForAllProtos(msg,p=>{
            if(p instanceof ProtoAsset){
                if(p.filepath!=null){
                    html+=  '<video controls src="'+p.filepath+'" style="width:100%;">' +
                                '<p class="missing_data">Video is not supported in your browser.<br>' +
                                'File "'+p.name+'" of type "'+p.mimeType+'" with size "'+this.formatBytes(p.size)+'" cannot be played.' +
                                '</p>'+
                            '</video>'
                }else
                    html+='<div class="missing_data">Not exported file "'+p.name+'" of type "'+p.mimeType+'" with size "'+this.formatBytes(p.size)+'".</div>';
            }
        });
        return this.createMessageItemContent(msg, header, html, isQuote);
    }

    /**
     * @param {Message} msg the message object
     * @param {String} header the message object
     * @param {Boolean} isQuote the message object
     * @returns {string} the html code
     */
    generateANY_ASSET(msg, header, isQuote) {
        let html="";
        this.runForAllProtos(msg,p=>{
            if(p instanceof ProtoAsset){
                html+="<div class=\"message_download\">" +
                            (p.filepath==null?"<div>":"<a href=\""+p.filepath+"\" target=\"_blank\">")+
                                '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="40" version="1.1" class="svg">'+
                                    '<path fill-opacity="0" stroke-width="2" d="M16 0L8 0Q0 0,0 8L0 32Q0 40,8 40L22 40Q30 40,30 32L30 14"/>'+
                                    '<path fill-opacity="0" stroke-width="2" d="M16 0L16 12Q16 14,24 14L30 14Z"/>'+
                                    (p.filepath==null?"":'<path fill-opacity="0" stroke-width="4" d="M15 14L15 35"/>' +
                                        '<path fill-opacity="0" stroke-width="4" d="M6 26L13 33Q15 36,17 33L24 26"/>')+
                                '</svg>'+
                            (p.filepath==null?"</div>":"</a>")+
                            "<div style=\"padding-left:10px;\">" +
                                "<div>"+p.name+"</div>" +
                                "<div class=\"color_less\">"+this.formatBytes(p.size)+" "+p.mimeType+"</div>" +
                            "</div>" +
                        "</div>";
            }
        });
        return this.createMessageItemContent(msg, header, html, isQuote);
    }

    /**
     * @param {Message} msg the message object
     * @param {String} header the message object
     * @param {Boolean} isQuote the message object
     * @returns {string} the html code
     */
    generateIMAGE_ASSET(msg, header, isQuote) {
        let html="";
        this.runForAllProtos(msg,p=>{
            if(p instanceof ProtoAsset){
                if(p.filepath!=null){
                    html+='<img style="max-width:100%;" src="'+p.filepath+'" alt="'+p.name+'"/>';
                }else
                    html+='<div class="missing_data">Not exported file "'+p.name+'" of type "'+p.mimeType+'" with size "'+this.formatBytes(p.size)+'".</div>';
            }
        });
        return this.createMessageItemContent(msg, header, html, isQuote);
    }

    /**
     * @param {Message} msg the message object
     * @param {String} header the message object
     * @param {Boolean} isQuote the message object
     * @returns {string} the html code
     */
    generateTEXT_EMOJI_ONLY(msg, header, isQuote) {
        return this.generateTEXT(msg, header, isQuote,["font_big"]);
    }

    /**
     * @param {Message} msg the message object
     * @param {String} header the message object
     * @param {Boolean} isQuote the message object
     * @param {String[]} styleClasses
     * @returns {string} the html code
     */
    generateTEXT(msg, header, isQuote, styleClasses=[]) {
        let html="";
        let text="";
        this.runForAllProtos(msg,p=>{
            if(p instanceof ProtoText){
                html+=this.getTextItem(p, styleClasses);
                text+=p.content;
            }else if(p instanceof ProtoEdited){
                if(p.text!=null){
                    html+=this.getTextItem(p.text, styleClasses);
                    text+=p.text.content;
                }
            }
        });
        return this.createMessageItemContent(msg, header, html, isQuote,text);
    }

    /**
     * @param {ProtoText} protoText
     * @param {String[]} styleClasses
     * @returns {string} the html code
     */
    getTextItem(protoText, styleClasses=[]){
        // MISSING: _linkPreviews
        return "<div class=\""+styleClasses.join(" ")+"\">"+this.getMention(protoText.mentions, protoText.content)+"</div>";
    }

    /**
     * @param {Mention[]} mentions
     * @param {String} textMessage
     * @returns {string} the html code
     */
    getMention(mentions, textMessage){
        if(mentions.length===0)
            return this.getTextHtml(textMessage);
        let html=textMessage;
        let add=0;
        mentions.sort((a,b)=>a.start-b.start);
        for(let mention of mentions){
            if(mention.userId!=null){
                let user=this._cea.getUser(mention.userId);
                let res="<span class=\"accent-color clickable\" onclick=\"showUserDetails(\'"+user.userId+"\');\">"+
                    html.substr(mention.start+add,mention.length)
                +"</span>";
                html=html.substring(0, mention.start+add)+res+html.substring(mention.start+add+mention.length);
                add+=res.length-mention.length;
            }
        }
        return this.getTextHtml(html);
    }
    /**
     * @param {String} text
     * @returns {String} html
     */
    getTextHtml(text){
        return text.replace(/(?:\r\n|\r|\n)/g, '<br>').replace(/(http[s]?:\/\/.*?)(\s|$)/g,"<a href=\"$1\">$1</a>"); // replace links
    }

    /**
     * @param {Message} msg the message object
     * @param {Boolean} isQuote
     * @returns {string} the html code
     */
    getMsgHeader(msg, isQuote= false){
        let user=this._cea.getUser(msg.userId);
        return this.getCustomHeader(msg,
            '<div onclick="showUserDetails(\''+user.userId+'\');\" class="message_header_icon clickable">'+this.getProfilePicture(user)+"</div>",
            "<div class=\"accent-color message_header_name\" data-accent=\""+user.accent_color+"\">"+
                user.name+
                ((msg.editTime==null)?"":
                    "<div class=\"message_edited\"><div class=\"turn-45\">&#x270f;</div><div style=\"margin-left:3px;\">"+
                        ((msg.editTime.toLocaleDateString()===msg.time.toLocaleDateString()
                            )?"":msg.editTime.toLocaleDateString()+" - ")+
                        msg.editTime.toLocaleTimeString().substring(0,5)+
                    "</div></div>")+
            "</div>",
            isQuote);
    }

    /**
     * @param {Message} msg the message object
     * @param {String} imageHtml
     * @param {String} contentHtml
     * @param {Boolean} isQuote
     * @returns {string} the html code
     */
    getCustomHeader(msg, imageHtml, contentHtml, isQuote= false){
        if(imageHtml==null)
            imageHtml='<div class=\"message_header_icon accent-color\"></div>';
        return  "<div class=\"message_header\">" +
            (!isQuote?(imageHtml):"")+
            contentHtml+
            (!isQuote?"<div class=\"message_item_right_space\">"+msg.time.toLocaleDateString()+"<br>"+msg.time.toLocaleTimeString().substring(0,5)+"</div>":"")+
            "</div>"+
            ((msg.quote==null)?"":this.getQuoteMsg(this._currentConversation.messages.get(msg.quote.msgId)));
    }

    /**
     * @param {Message} quotedMsg
     * @returns {string} the html code
     */
    getQuoteMsg(quotedMsg ){
        if(quotedMsg==null)
            return "";
        return  "<div class=\"message_item_content\">"+
                    "<div class=\"message_quote\">" +
                        this.createMessageItem(quotedMsg,true)+
                        "<div>Original message from "+quotedMsg.time.toLocaleDateString()+"</div>"+
                    "</div>" +
                "</div>";
    }

    /**
     * @param {User} user
     * @returns {String}
     */
    getProfilePicture(user){
        return '<div class="item_profile_picture_container">'+
            (user.picture==null?
                '<div class="left_item_textpic">'+user.getShort()+'</div>':
                '<img src="'+user.picture.filename+'" alt="'+user.getShort()+'">')
            +'</div>';
    }

    /**
     * @callback protoToHtml
     * @param {MessageProto} element
     * @returns {String} the html code
     */

    /**
     * @param msg
     * @param {protoToHtml} callback
     * @returns {string}
     */
    runForAllProtos(msg, callback){
        /** @type {string} */
        let result="";
        for (let proto of msg.protos) {
            result+=callback(proto);
        }
        return result;
    }

    /**
     * @callback contentToHtml
     * @param {MessageContent} element
     * @returns {String} the html code
     */

    /**
     * @param {Message} msg
     * @param {contentToHtml} callback
     * @returns {string}
     */
    runForAllContent(msg, callback){
        /** @type {string} */
        let result="";
        for (let content of msg.contents) {
            result+=callback(content);
        }
        return result;
    }

    // FROM https://stackoverflow.com/questions/15900485/correct-way-to-convert-size-in-bytes-to-kb-mb-gb-in-javascript
    formatBytes(a,b=2){
        if(0===a)
            return"0 Bytes";
        const c=0>b?0:b, d=Math.floor(Math.log(a)/Math.log(1024));
        return parseFloat((a/Math.pow(1024,d)).toFixed(c))+" "+["Bytes","KB","MB","GB","TB","PB","EB","ZB","YB"][d]}
}